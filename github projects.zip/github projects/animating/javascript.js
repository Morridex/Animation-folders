const canvas = document.createElement("canvas");
document.body.appendChild(canvas);
const ctx = canvas.getContext("2d");

canvas.setAttribute("width", "400");
canvas.setAttribute("height", "400");
/* canvas.style.cssText = "width : 400px; height : 400px; "; */
/* border : 2px solid black; background-color: aqua */

var times = 0;

class Ball {
  constructor(x, y, radius, color) {
    this.x = x;
    this.y = y;
    this.radius = radius;
    this.color = color;
    this.kretanje = true;
    this.velocity = 0;
    this.gravity = 0;
    this.switch = true;
    this.close = [];

    this.draw = function () {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fillStyle = this.color;
      ctx.fill();
      ctx.closePath();
    };

    //bouncy ball --> provjeriti na drugom kompu zbog brzine procesiranja
    this.animate = function () {
      this.velocity++;
      this.y += this.velocity;
      if (this.y + this.radius + 50 >= canvas.height) {
        this.velocity -= 5;
        console.log(this.velocity);
      }
    };

    // kuglica ide gore dolje
    /* this.animate = function () {
      console.log(this.y);
      if (this.kretanje === true) {
        this.y += 5;
      }
      if (this.kretanje === false && this.y > this.radius) {
        this.y -= 5;
      } else {
        this.kretanje = true;
      }
      if (this.y + this.radius >= canvas.height) {
        this.kretanje = false;
      }
    }; */

    //blago micanje loptice desno
    /* this.animate = function () {
      if (this.kretanje === true) {
        this.velocity += 0.1;
        this.y += this.velocity;
      }
      if (this.y + this.radius > 350) {
        this.velocity = 0;
        this.kretanje = false;
      }
      if (this.kretanje !== true) {
        this.y -= 5;
        this.switch = false;
      }
      if (this.switch === false && this.y < 150) {
        this.x += 2;
        this.y -= 2;
        this.gravity = 1;
        this.kretanje = true;
        this.switch = true;
      }
      if (this.gravity === 1 && this.y < 200) {
        this.x += 2;
        this.y -= 2;
        this.kretanje = true;
      }
    }; */

    //malo bolje
    /* this.animate = function () {
      if (this.kretanje === true) {
        this.velocity += 0.1;
        this.y += this.velocity;
      }
      if (this.y + this.radius > 350) {
        this.velocity = 0;
        this.kretanje = false;
      }
      if (this.switch === true && this.kretanje === false && this.y > 150) {
        this.y -= 2;
        this.x += 0.3;
        this.gravity = 1;
      }
      if (this.gravity === 1 && this.y < 150) {
        this.kretanje = true;
      }
    }; */

    /* this.animate = function () {
      if (this.kretanje === true) {
        this.y += 5;
      }
      if (this.kretanje === false && this.y > this.radius) {
        this.y -= 5;
      } else {
        this.kretanje = true;
      }
      if (this.y + this.radius >= canvas.height) {
        this.kretanje = false;
      }
    }; */

    /*     this.samonoviarray = function () {
      if (this.kretanje === true) {
        if (this.x < 100) {
          this.x--;
        } else if (this.x > 100) {
          this.x++;
        }
        if (this.x === 100) this.color = "yellow";
      }
    }; */

    this.kruzno = function () {
      if (this.kretanje === true) {
        if (this.x < 100) {
          this.x++;
        } else if (this.x > 100) {
          this.x--;
        }
        if (this.x === 100) {
          this.color = "blue";
          this.kretanje = false;
        }
      }
      if (this.kretanje === false) {
        this.x += 2;
      }
    };
  }
}
let noviarray = [];
let particles = [];

let Lopta = new Ball(100, 100, 50, "red");
for (i = 0; i < 200; i++) {
  let a = Math.floor(Math.random() * 200) + 10;
  let b = Math.floor(Math.random() * 200) + 10;
  particles.push(new Ball(b, a, 2, "green"));
  noviarray.push(new Ball(b, a, 2, "green"));
}

let firsthalf = noviarray.splice(0, 100);
let secondhalf = noviarray.splice(-100);

function update() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  Lopta.draw();
  Lopta.animate();

  for (let i = 0; i < particles.length; i++) {
    particles[i].draw();
    particles[i].animate();
    particles[i].kruzno();
  }
  /*   for (i = 0; i < noviarray.length; i++) {
    noviarray[i].draw();
    noviarray[i].samonoviarray();
    noviarray[i].animate();
  } */
  window.requestAnimationFrame(update);
}
update();

// for testing purposes
/* setInterval(update, 1000 / 20); */
