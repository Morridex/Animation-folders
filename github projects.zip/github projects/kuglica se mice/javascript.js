const canvas = document.createElement("canvas");
document.body.appendChild(canvas);
const ctx = canvas.getContext("2d");
canvas.setAttribute("width", "400");
canvas.setAttribute("height", "400");
canvas.style.border = "5px solid black";

let randBroj;
let drugiRandBroj;

const ball = {
  x: 200,
  y: 200,
  radius: 30,
  smjer: true,

  crtanje: function () {
    ctx.clearRect(0, 0, 400, 400);
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fillStyle = "red";
    ctx.fill();
  },
};

function odredjivanjeBroja() {
  randBroj = Math.ceil(Math.random() * 10);
  drugiRandBroj = Math.ceil(Math.random() * 10);
}
odredjivanjeBroja();

let smjerBool = true;

/* const novo = JSON.parse(JSON.stringify(ball));
novo.x = Math.random() * 400;
(novo.crtanje = function () {
  ctx.clearRect(0, 0, 400, 400);
  ctx.beginPath();
  ctx.arc(novo.x, novo.y, novo.radius, 0, Math.PI * 2);
  ctx.fillStyle = "red";
  ctx.fill();
}),
  console.log(novo); */

setInterval(() => {
  ball.crtanje();
  /*   novo.crtanje(); */
  if (ball.smjer === true) {
    if (smjerBool === true) {
      odredjivanjeBroja();
      smjerBool = false;
    }
    ball.x += randBroj;
    ball.y += drugiRandBroj;
  }
  if (
    ball.x >= canvas.width - ball.radius ||
    ball.y >= canvas.height - ball.radius
  ) {
    ball.smjer = false;
  }
  if (ball.smjer === false) {
    if (smjerBool === false) {
      odredjivanjeBroja();
      smjerBool = true;
    }
    ball.x -= randBroj;
    ball.y -= drugiRandBroj;
  }
  if (ball.x <= ball.radius || ball.y <= ball.radius) {
    ball.smjer = true;
  }
}, 1000 / 60);
