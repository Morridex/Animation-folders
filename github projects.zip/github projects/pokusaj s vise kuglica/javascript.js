const canvas = document.createElement("canvas");
document.body.appendChild(canvas);
const ctx = canvas.getContext("2d");

canvas.style.cssText = "border: 2px solid black; background-color: aqua;";
canvas.setAttribute("width", "400");
canvas.setAttribute("height", "400");

class Ball {
  constructor(x, y, radius, color) {
    this.x = x;
    this.y = y;
    this.radius = radius;
    this.color = color;
    this.kretanje = true;

    this.draw = function () {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fillStyle = this.color;
      ctx.fill();
      ctx.closePath();
    };

    this.animate = function () {
      if (this.kretanje === true) {
        this.x++;
        this.y++;
      }
      if (
        this.x >= canvas.width - this.radius ||
        this.y >= canvas.height - this.radius
      ) {
        this.kretanje = false;
      }
      if (this.kretanje === false) {
        this.x--;
        this.y--;
      }
      if (this.x <= this.radius || this.y <= this.radius) {
        this.kretanje = true;
      }
    };
  }
}

let kugla = new Ball(200, 200, 30, "green");
let kuglice = [];

for (let i = 0; i < 1000; i++) {
  let x = Math.floor(Math.random() * 400) - 5;
  let y = Math.floor(Math.random() * 400) - 5;
  kuglice.push(new Ball(x, y, 2, "red"));
}

function update() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  kugla.draw();
  for (i = 0; i < kuglice.length; i++) {
    kuglice[i].draw();
    kuglice[i].animate();
  }

  //stalno povecavanje i smanjivanje zelene kugle

  /*   if (kugla.kretanje === false) {
    kugla.radius -= 2;
    if (kugla.radius === 10) {
      kugla.kretanje = true;
    }
  } else {
    kugla.radius += 2;
    if (kugla.radius === 200) {
      kugla.kretanje = false;
    }
  } */

  window.requestAnimationFrame(update);
}
update();

window.addEventListener("keypress", (event) => {
  switch (event.key) {
    case "w":
      kugla.y -= 5;
      break;
    case "s":
      kugla.y += 5;
      break;
    case "a":
      kugla.x -= 5;
      break;
    case "d":
      kugla.x += 5;
      break;
    case "e":
      kugla.radius += 5;
      break;
    case "q":
      kugla.radius -= 5;
      break;
    case "c":
      kugla = new Ball(100, 100, 20, "yellow");
      break;
    case "x":
      kugla = new Ball(300, 300, 30, "orange");
      break;
    case "r":
      kugla = new Ball(200, 200, 10, "green");
      break;
    case "j":
      canvas.style.backgroundColor = "white";
      break;
    case "k":
      canvas.style.backgroundColor = "gray";
      break;
    case "l":
      canvas.style.backgroundColor = "black";
      break;
    case "h":
      canvas.style.backgroundColor = "aqua";
      break;
  }
});

canvas.addEventListener("click", (event) => {
  kuglice.push(new Ball(event.clientX, event.clientY, 10, "blue"));
});
