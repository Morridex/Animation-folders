const canvas = document.createElement("canvas");
document.body.appendChild(canvas);
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

function draw() {
  ctx.beginPath();
  ctx.arc(
    canvas.width / 2,
    canvas.height / 2,
    canvas.width / 5,
    0,
    Math.PI * 2
  );
  ctx.fillStyle = "white";
  ctx.fill();
  ctx.closePath();
}
draw();

/* function line() {
  ctx.beginPath();
  ctx.lineWidth = 5;

  //step1
  ctx.moveTo(canvas.width / 4, canvas.height / 2);
  ctx.lineTo(canvas.width / 2.3, canvas.height / 2);
  ctx.stroke();

  //step2
  ctx.lineTo(canvas.width / 2.3, canvas.height / 2.5);
  ctx.stroke();

  //step3
  ctx.lineTo(canvas.width / 1.5, canvas.height / 2.5);
  ctx.stroke();

  //step4
  ctx.lineTo(canvas.width / 1.5, canvas.height / 4.5);
  ctx.stroke();
} */
/* line(); */
var timer = 0;
var number = 0;
var moving = 0.1;
var quarter = 4;
var step2 = 2;
var number2 = 0;
/* document.body.style.backgroundColor = "black"; */

//step1 moving
var interval = setInterval(() => {
  timer++;
  console.log(timer);
  moving += 0.1;
  var a = quarter - moving;
  number = canvas.width / a;
  ctx.beginPath();
  ctx.lineWidth = 10;
  ctx.moveTo(canvas.width / 4, canvas.height / 2);
  ctx.lineTo(number, canvas.height / 2);
  ctx.stroke();
  if (timer === 17) {
    clearInterval(interval);
    moving = 0;
  }
}, 1000 / 5);

//step2
var interval2 = setInterval(() => {
  if (timer >= 17) {
    timer++;
    console.log(timer);
    moving += 0.1;
    var b = step2 + moving;
    var number2 = canvas.height / b;
    ctx.beginPath();
    ctx.moveTo(number, canvas.height / 2);
    ctx.lineTo(number, number2);
    ctx.stroke();
  }
  if (timer === 22) {
    clearInterval(interval2);
    moving = 0;
  }
}, 1000 / 5);

//step3
var interval3 = setInterval(() => {
  if (timer >= 22) {
    timer++;
    console.log(timer);
    moving += 0.1;
    var c = 2.3;
    var number = canvas.width / c;
    c -= moving;
    var number2 = canvas.height / 2.5;
    ctx.moveTo(number, number2);
    ctx.lineTo(canvas.width / c, number2);
    ctx.stroke();
  }
  if (timer === 30) {
    clearInterval(interval3);
    moving = 0;
  }
}, 1000 / 3);

//step 4
var interval4 = setInterval(() => {
  if (timer >= 30) {
    timer++;
    console.log(timer);
    moving += 0.1;
    ctx.moveTo(canvas.width / 1.5, canvas.height / 2.5);
    ctx.lineTo(canvas.width / 1.5, canvas.height / 4.5);
    ctx.stroke();
  }
});
